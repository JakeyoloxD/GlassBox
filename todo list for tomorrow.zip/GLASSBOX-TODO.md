# Glassbox — TODO for tomorrow (surface the crypto visuals + fix the tutorial)

**Read this whole file before touching code.** It encodes what I already
discovered so you don't re-learn it. Written 2026-08-26.

---

## 0. Mission this session

Keep the structure-engine app and its import/analyse window (the user loves it).
**Add back the visual analysis panels and a working guided tour**, wired so the
UI actually works. The user's words: "you lost a lot of the visual tests from
our original one, you also lost the tutorial where it walks you through what
they all do… add the visuals from glassbox(7) and wire them up so the ui works."

The thesis is unchanged (from `GLASSBOX-ROADMAP.md`): **give it bytes, it tells
you what they are and shows you why.** Structure discovery is the front door;
crypto is the drill-down.

---

## 1. Ground truth (verified this session — don't re-litigate)

- The uploaded `Glassbox_7_.html` is **byte-identical** to the delivered build
  (`md5 00ea7323f6cb19b97ea4a86514ab0d9a`). It is NOT a richer file. It is the
  current structure engine.
- **The crypto/weakness renderers already exist in `Glassbox_7`** but are never
  booted, so they are invisible/unreachable: `view.matrix` (DDT/LAT),
  `view.sboxGrid`, `view.spectrum` (Walsh), `view.walshAncestry`, `view.anf`,
  `view.aesDerivation`, `view.fieldMicroscope`, `view.bitgrid` (influence),
  `view.table`. The TYPES are defined too: `crypto.sbox`, `analysis.ddt`,
  `analysis.lat`, `analysis.walsh`, `analysis.walshAncestry`, `analysis.anf`,
  `analysis.influence`, `analysis.aesDerivation`, `math.gfMultiply`.
- **The tutorial is orphaned.** `GUIDE_STEPS` still exists but every step calls
  `guideSelect("SBOX-01")` / `guideSelect("DDT-01")`, and those objects are NOT
  booted in the structure engine → the tour walks through empty space. It also
  only covers 2 crypto topics and none of the structure panels.
- **The structure panels ARE booted and working** (verified via jsdom, real
  imports): hypotheses board, signatures, stride, columns, segments, strings,
  digraph, hilbert, bitStructure, byteFrequency, entropyTimeline, repetition,
  byteMap (DATA-01), decodeChain (transform).
- The engine itself is sound: the module tests pass (43/15/20/26 + e2e 31,
  one soft 4 MB perf threshold). The verdict banner I added classifies
  structured / random / text / weak-crypto correctly.

### The ONLY things that live solely in the old build

These are NOT in `Glassbox_7`; they must be ported from the reference file
(see §2): the **ciphertext raster with drag-select regions**, the **weakness
RAG scoring** (`assessObject` / `WEAK_COLOUR`), and the **Walsh-Hadamard
randomness test panel + null-distribution calibration**. Everything else
(DDT/LAT/Walsh/S-box/ANF/influence renderers + computes) is already inside
`Glassbox_7`.

---

## 2. File map (all in `/mnt/user-data/outputs`, because the FS resets nightly)

| File | What it is | Use |
|---|---|---|
| `Glassbox.html` | **The working app** = structure engine = Glassbox_7. md5 `00ea7323…`. 7986 lines. EDIT THIS. | primary target |
| `Glassbox-original-reference.html` | The pre-structure-engine build (316 KB). Has the raster+regions+weakness RAG+WHT panel. md5 `280266e5…`. **Read-only porting source.** | copy code FROM here |
| `se_env.harness.js` | jsdom boot harness for the app (real DOM + real events). | verification |
| `GLASSBOX-TODO.md` | this file | plan |

If the user re-uploads `Glassbox_7_.html`, confirm md5 `00ea7323…` and treat it
as identical to `outputs/Glassbox.html`. Engine module tests (`t10E.js` etc.)
were in `/mnt/user-data/uploads/`; if gone, the embedded engine in the HTML is
the source of truth and is tested directly via jsdom (see §7).

---

## 3. Decisions (locked to the user's "if you just say go" defaults; change only if user says otherwise)

1. **Crypto visuals = drill-down, not always-on.** They appear only when a
   candidate S-box/permutation or AES constant is found, OR on explicit user
   action ("Analyse selection as S-box"). Rationale: a DDT/LAT of arbitrary
   non-S-box bytes is confident noise → violates roadmap "no charts without
   claims" / "no confident wrong answers".
2. **Full cluster** when it opens: S-box grid → DDT, LAT, Walsh(+ancestry),
   ANF, influence. AES-derivation + field-microscope reachable but one step
   deeper (don't crowd the first open).
3. **Port the ciphertext raster drag-select + weakness RAG** onto a raster
   panel (see §6-T3 for exactly how, given the simpler pointer model here).
4. **Two-act guided tour with a small embedded sample** so the tour always has
   data.
5. **Include the WHT randomness panel + null-distribution** (port from
   reference), living in the crypto cluster.

---

## 4. Invariants — assert these hold after every change (roadmap §1)

- **I1** Definitions serialise; `COMPUTED`/`CACHE` never serialise.
- **I3** Renderers never compute maths — they match atoms only. (So the verdict
  and RAG must be computed in the `compute*` fn, then drawn. I already did this
  for `boardVerdict`.)
- **I5** No `eval`, `new Function`, network, or remote resources.
- **I6** Every hypothesis carries ≥1 evidence; every evidence has a byte range
  or a measured number.
- **I7** Analysis reads bytes at its own chain node; a finding from decoded
  bytes cites the decode.
- **I9** Every compute is pure + synchronous (topological recompute depends on
  it — do NOT introduce async decode/analysis).
- **New:** crypto panels only exist with evidence or explicit user action.

---

## 5. Key code anchors in `Glassbox.html` (line numbers approx as of md5 00ea7323; grep the function names, they're stable)

**Spawn / graph primitives (runtime object creation works — boot uses them):**
- `nextEid(prefix)` ~697 · `makeObject(type,def,visual)` ~702 ·
  `registerDependency(from,to,kind)` ~782 · `markDirty(eid)` ~805 ·
  `recomputeAll()` ~843 · `getObj(eid)` · `focusAndSelect(eid)` ~6903 ·
  `sourceOfType(eid,type)` ~792 · `sourcesOf(eid)` · `byteSourceOf(eid)` ~4630.

**S-box + crypto computes (already present, reuse):**
- `computeSbox(o)` ~1661. Honours `definition.construction`:
  `"aes"` builds AES; **`"explicit"` uses `definition.table` (array of 256
  ints)** — this is how you feed discovered bytes.
- DDT/LAT/Walsh/ANF/influence computes exist; their resolvers use
  `sourceOfType(eid,"crypto.sbox")` (see resolvers ~1056/1101/1137/1186/1239),
  so `registerDependency(sboxEid, ddtEid)` makes the S-box the source. Verify
  the *computes* (not just resolvers) read via `sourcesOf(o.eid)[0]`.

**Discovery hooks (the drill trigger already exists in the data):**
- `findPermutationTables(bytes)` ~2234, `scanCryptoConstants`, `identifyFormat`
  ~2019 — run inside `computeSignatures`; result carries `permutations` and
  `constants`.
- `buildHypotheses` (region 10L) ~4364. It ALREADY emits drillable crypto
  hypotheses:
  - ~4430 `_hyp(HYP.CRYPTO, "N candidate S-box(es) (256-byte permutation…)",
    0.6, …, { offsets: [...], drillable: true })`
  - ~4422 AES-constant group `{ algo, count, drillable: /AES/.test(algo) }`
  - `HYP` kinds ~4338: FORMAT, ENCODING, RECORD, FIELD, CRYPTO, REGION, REPEAT,
    STRING.
  → **A hypothesis with `extra.drillable` and `extra.offsets` is the hook.**
- `computeHypothesisBoard(o,get)` ~4757; I added `boardVerdict(H,n)` right after
  it (returns `{level,label,note}`; levels weak|structured|text|random|empty).
- Hypothesis resolver ~4790 already flattens `h.ranges` → `byteRange` atoms for
  cross-highlight. Reuse this for cluster highlight.

**Renderers (all present):** search `RENDER["view.<name>"]`. Board renderer with
the verdict banner is `RENDER["view.hypotheses"]` (I rewrote it — banner at top,
`VCOL` map, list offset by `30+46`px; hit-test row offset must match).

**UI shell:**
- Ribbon: `RIBBON` object ~6869, `paintRibbon()` ~6888, `bindRibbonActions()`
  (maps button id → fn), `activeRibbonTab` ~6886. `rbGuide` entry ~6653.
  To add an action: add a `tool("rbXxx","Label","icon")` to a panel in `RIBBON`
  and an `rbXxx:fn` entry in the `bindRibbonActions` map.
- Commands: `COMMANDS.<name>` (e.g. `COMMANDS.test` ~6380). `runCommand(str)`.
  Add `COMMANDS.sbox`, `COMMANDS.wht`, etc. here if wanted.
- Guide: `GUIDE_STEPS` ~6687, `guideSelect(eid)` ~6673, `guideFeedback(t,d)`
  ~6681, `paintGuide()` ~6798, `guideShow()` ~6807, `guideNext/Back` ~6813,
  `startGuide()` ~6794, coach DOM `#guideCoach` ~551.
- Input flow (DO NOT BREAK): `loadInputBytes(bytes,name,kind)` ~6881,
  `analyseTextInput()` ~6886, `openDataFile(file)` ~6887, `showInputOverlay()`
  ~6879, welcome/input overlay `#welcomeOverlay` ~517, `#rawInputText` ~522.
- `boot()` ~7910; `makeObject` calls ~7955-7975; ends with
  `setTimeout(()=>showInputOverlay(true),40)`.
- Pointer handlers ~6974-7007 (mousedown autoscroll guard + pointerdown/move/
  up/cancel). Keydown ~7018 (already guarded for inputs + open overlays — keep).

---

## 6. Tasks (in build order)

### T1 — Crypto drill-down cluster  ★ core

**Goal:** clicking a drillable crypto hypothesis (or the manual command) opens a
linked, focused cluster of the crypto panels computed on the discovered bytes.

Steps:
1. Add `spawnSboxCluster(bytes, offset, label)`:
   - `const table = Array.from(bytes.slice(offset, offset+256));` (guard length
     ≥256; if a permutation, `findPermutationTables` already validated it).
   - `snapshot("open s-box view");`
   - `const sb = makeObject("crypto.sbox", {construction:"explicit", table},
     {x,y,w:300,h:300});` position the cluster to the right of / below the board
     in clear space (compute from existing object bounds to avoid overlap — see
     the overlap bug in §8).
   - `const ddt=makeObject("analysis.ddt",{},pos); lat=…lat; wal=…walsh;
     anf=…anf; inf=…influence;` push all to `S.doc.objects`.
   - `registerDependency(sb.eid, ddt.eid); …lat; …anf; …influence;`
     `registerDependency(lat.eid, wal.eid)` (Walsh slices LAT — check the
     original's dependency direction: in the reference boot, walsh depends on
     lat). Verify against reference `boot()`.
   - `[sb,ddt,lat,wal,anf,inf].forEach(o=>markDirty(o.eid)); recomputeAll();`
   - `focusAndSelect(sb.eid); paintObj(); paintDeps(); requestDraw();`
   - Idempotency: if a cluster for this offset already exists, focus it instead
     of spawning a duplicate (track by a tag on the sbox definition, e.g.
     `definition.origin = offset`).
2. Wire the trigger:
   - In the hypothesis click path (resolver/`semanticHitTest` on the board, or
     a dedicated "Open" affordance drawn on drillable rows), when the clicked
     `h.extra.drillable && h.extra.offsets`, call `spawnSboxCluster(bytes,
     offsets[0], h.title)`. Get `bytes` from `byteSourceOf(HYP-01)` →
     `COMPUTED.get(byteEid).bytes`.
   - Draw a small "⤢ open" chip on drillable hypothesis rows so it's
     discoverable (in `RENDER["view.hypotheses"].draw`, when `h.extra &&
     h.extra.drillable`). Extend `semanticHitTest` to return a distinct fact
     (e.g. `{kind:"hypothesis-drill", index}`) when the click lands on the chip.
3. Manual path: `COMMANDS.sbox` / ribbon "Analyse as S-box" → take the current
   selection's byte range (or the whole buffer if exactly 256 B) and call
   `spawnSboxCluster`.

**Gotchas:** confirm the crypto computes exist and are registered as TYPES in
this file (they are). Confirm `computeSbox` explicit path builds `table`,
`bijective`, `fixedPoints`, `n`, `bits` fields the renderers/RAG expect.

### T2 — Weakness RAG chips  ★ reuse from reference

Port `WEAK_COLOUR`, `WEAK_RANK`, and `assessObject(o,data)` from
`Glassbox-original-reference.html` (search those names). It returns
`{level, headline, detail, metric}` for ddt/lat/walsh/anf/influence/sbox and (if
you port the raster) ciphertext. Then in the frame chrome / each crypto
renderer's header, draw the RAG chip (green ≥ strong, amber = moderate, red =
weak). **Calibration is size-aware and load-bearing — copy the exact bands:**
- DDT: `q = U / (m%2?2:4)`; strong ≤2, moderate ≤8, weak else.
- LAT: `optL = round(2^(m/2))`; `q = maxAbs/optL`; strong ≤1.5, moderate ≤4.
- **Walsh: use `maxAbs/2` (W = 2·LAT) before comparing to `optL`** — this bug
  bit me once; the reference already has the fix.
- SAC/influence: `r = maxDeviation/ideal`; strong ≤0.15, moderate ≤0.3.
- ANF: `deg ≥ m-1` strong; `≥ m-2` moderate; weak else.
Put the compute in `assessObject` (called from the renderer for display only —
it reads already-computed exact numbers, so it doesn't violate I3).

### T3 — Ciphertext raster drag-select + region readout  ★ port + adapt

The reference has `view.raster`, and a region system: `summariseRegion`,
`regionAtoms`, `createRegionFromMarquee`, `drawMatrixRegions`, `S.doc.regions`,
plus a marquee in the pointer handler and an Arrange/Region mode.

**Adapt to the structure engine's simpler pointer model** (it has no
mode toggle; middle/alt = pan, left = click-select). Recommended:
- The structure engine already renders a byte raster as `view.byteMap`
  (DATA-01). Add **drag-select** to it: in the pointerdown/move/up handlers
  (~6974), when the press starts inside a `regionHitTest`-capable object and the
  pointer moves > 4px, rubber-band a marquee (world coords), and on up call
  `createRegionFromMarquee`. On a plain click keep the existing select. (This is
  the "maybe → region/pan" promotion pattern from the reference; port it but
  keep left-drag-on-empty = pan.)
- Port `summariseRegion` for a raster: report cells, ones, zeros, %ones, and a
  finding ("≈50% → looks random" vs "far from 50% → biased/structured").
- Draw region rectangles + a small readout via `drawMatrixRegions`.
- Add `regionHitTest(o,rect,data)` to `view.byteMap` mapping pixels→byte range.
- Regions persist in `S.doc.regions` (serialisable → undo works).

**Do NOT reintroduce these bugs (all hit me):**
- Keep `let drag = null;` — an edit once deleted it → every handler threw
  `ReferenceError: drag is not defined` in strict mode → all interaction dead.
- Per-object raster image cache keyed by `eid + n:width:ones`, NOT `n:width`
  (two same-size rasters collided → identical pixels).
- Don't `setPointerCapture` on a plain click; capture only once a drag starts;
  add `pointercancel`/`lostpointercapture` cleanup (stuck capture steals
  overlay/textarea focus → "can't type" + "it's tracking").

### T4 — Walsh-Hadamard randomness panel + calibration  ★ port from reference

Port `computeWhtTest`, `RENDER["view.whtSpectrum"]`, `computeNullDistribution`,
`RENDER["view.nullDist"]`, and the math helpers `makeRng`, `binomSfHalf`,
`lgamma`, `erf`, `whtPeakPValue`, `whtPeak`, `runsTestP`, `columnPeriodicity`,
`fwht` (fwht already exists in region 10A — reuse, don't duplicate). These are
marked `statistical:true`; if this file has a no-float invariant self-test
(check region 23), exempt `statistical:true` objects like the reference does.
**Copy the calibration wording as measured, not "~2×"** — real inflation is
1.0–1.3×, shrinking with N; the reference text is already corrected.

Spawn the WHT panel inside the crypto cluster (or offer via command) on a
bitstream/keystream selection.

### T5 — Rebuild the guided tour  ★ core (currently broken)

Replace `GUIDE_STEPS` with a robust two-act tour. Each step:
`{ title, body, target?: eid, show(): fn, guard?: ()=>bool }`. In `guideShow()`,
if `guard` is false or `getObj(target)` is missing, **skip with a note** instead
of pointing at nothing (this is why the current tour is broken).

- **Act 1 — front door (always):**
  1. Load the embedded sample (see below) so the board is populated.
  2. Read the verdict banner on `HYP-01` — structured/random/text/weak.
  3. `STRD-01` stride: what a periodicity peak means.
  4. `COLS-01` columns/struct: fields inside a record.
  5. `DIG-01` digraph + `HIL-01` Hilbert: the "see the structure" money shot.
  6. `ENT-01` entropy timeline + `SEG-01` segments: where regions change.
  7. `STG-01` strings.
- **Act 2 — drill-down (guard: a drillable crypto hypothesis exists):**
  1. Open the S-box cluster (call `spawnSboxCluster`).
  2. Interrogate one mapping on the S-box grid.
  3. DDT: differential (click a strong Δx/Δy cell).
  4. LAT/Walsh: linear approximation + the weakness verdict chip.

Embed a tiny sample (a few KB) built at boot in JS (NO network, I5): a header +
a repeating 48/64-byte record section (u32 counter, unix ts step, ASCII tag,
random payload) + an AES S-box block at a known offset + a short high-entropy
tail. This exercises records, fields, a discovered S-box, and an entropy shift —
so both acts have something real to point at. Store it as the sample the "Take
the tour" and a "Load sample" button feed to `loadInputBytes`.

Launch: add "Take the guided tour" and "Load sample" buttons to the input
overlay; keep the `rbGuide` ribbon entry.

### T6 — Wiring + discoverability

- Ribbon: add a "Crypto" or "Drill-down" panel with "Analyse selection as
  S-box" and (if present) "Open WHT test". Add tour + sample buttons to Learn.
- Ensure new fact kinds have resolvers (grep `registerResolver`): the crypto
  ones already exist (`sbox-cell`, `ddt-cell`, `lat-cell`, `walsh-coefficient`,
  `anf-monomial`, `influence-cell`, `walsh-ancestry-stage`). Add resolvers for
  any NEW kinds you introduce (`hypothesis-drill`, raster region, WHT).
- Keep the input/analyse window and its wiring untouched.

---

## 7. Verification protocol — MANDATORY, do this, do not trust the headless stub

**Lesson from this project:** a DOM-faking stub passes while the real browser is
broken. Three real bugs (deleted `let drag`, keyboard typing-hijack, stuck
pointer capture) all passed a stub and only surfaced in **jsdom with dispatched
events**. Use jsdom.

Setup (jsdom 30 is installable from npm; the registry is allowed):
```
cd /home/claude && npm init -y >/dev/null 2>&1 && npm install jsdom >/dev/null
```
Use `outputs/se_env.harness.js` (a `boot(htmlPath)` that stubs only the 2D
canvas context and wires jsdom globals, then evals the script with an appended
`globalThis.__api = {S,V,COMPUTED,getObj,loadInputBytes,byteSourceOf,RENDER,…}`
hook). Pattern for a test:
```js
const {boot}=require("./se_env.harness.js");
const B=boot("/mnt/user-data/outputs/Glassbox.html");
setTimeout(()=>{ const A=B.get(); /* dispatch events on #cv, click buttons,
  loadInputBytes(...), assert COMPUTED + object graph + renderer.draw() */ },600);
```

**Checks that must pass before delivering:**
1. Boots with no thrown error; `HYP-01`/`DATA-01` exist.
2. Import still works via real events: open overlay → set `#rawInputText` →
   click `#inputAnalyze` → board populates + overlay closes; file path via
   `loadInputBytes`.
3. **Typing not hijacked:** dispatch keydown `f`, `/`, `1` on `#rawInputText`;
   assert `V.z` unchanged and `document.activeElement === #rawInputText`.
4. **Pan works + can't stick:** middle-drag changes `V.x`; a `pointercancel`
   resets `drag` to null and releases capture.
5. **Drill-down:** load the embedded sample → find the drillable crypto
   hypothesis → trigger it → assert `crypto.sbox` + `analysis.ddt/lat/walsh`
   objects created, their `COMPUTED` entries exist, and each renderer `.draw()`
   runs without throwing. DDT `uniformity`, LAT `nonlinearity` present.
6. **Weakness RAG:** for the discovered AES S-box, `assessObject` on DDT = strong
   (uniformity 4), on an identity table = weak.
7. **Region drag-select:** simulate a marquee on the byte raster → a region is
   created in `S.doc.regions` with correct %ones; plain click still selects.
8. **Tour:** step through every `GUIDE_STEPS` entry; assert each either selects a
   present object or skips cleanly (NO pointing at a missing eid, NO throw).
9. Regression: the structure verdicts still classify structured/random/text/ecb
   correctly (reuse this session's `se_verdict` assertions).
10. Any in-file self-tests (region 23) still green; the "renderers don't compute"
    (I3) and hypothesis-evidence (I6) asserts hold.

Also re-run the engine module tests if the `t*.js` files are present in uploads
(`node t10E.js` … `node t-e2e.js`) — they validate the pure engine unchanged.

---

## 8. Bug graveyard — do NOT resurrect these (each cost a round-trip)

1. Deleting `let drag = null;` → strict-mode `ReferenceError` in every pointer
   handler → all interaction dead. Keep it.
2. Global keydown only ignoring `cmdEl` → typing `f`/`/`/`1` in a textarea fired
   canvas shortcuts. Guard must bail for INPUT/TEXTAREA/SELECT/contenteditable
   AND when `anyOpenOverlay()`. (Already fixed in the working file — preserve.)
3. Middle-click with no `preventDefault` on `mousedown` → browser autoscroll
   instead of pan. Keep the `mousedown` guard.
4. `setPointerCapture` on every click + no `pointercancel`/`lostpointercapture`
   → stuck capture → canvas keeps "tracking", steals focus from overlays/text.
   Capture only when a drag begins; always clean up.
5. Raster image cache keyed on `n:width` only → two same-size rasters shared one
   canvas (identical pixels). Key on `eid + n:width:ones`, per-object Map.
6. Walsh RAG comparing a W-scale peak (2×LAT) to an L-scale optimum → mislabel.
   Use `maxAbs/2`.
7. Newly created object placed on top of an existing one → drag hits the wrong
   (stacked) object. Compute a clear position from existing bounds when
   spawning the cluster.
8. Claiming "verified" from a headless stub. Only jsdom + dispatched events
   counts (see §7).
9. Roadmap defect list (its `<details>` block) — 12 scoring defects in the
   engine, each caught by a test. Do NOT touch the engine scoring; if you must,
   re-run `t-e2e.js` and the 10x tests.

---

## 9. Acceptance criteria (tell the user it's done when ALL hold)

- Load a `.bin` with an S-box inside → board shows a drillable crypto
  hypothesis → clicking it opens the S-box/DDT/LAT/Walsh/ANF/influence cluster on
  those exact bytes, each with a RAG chip, and clicking a DDT/LAT cell
  cross-highlights.
- Load random → green "no structure"; load records → "structure detected" with
  the record/field panels; load prose → "text". (Unchanged, still true.)
- Drag a box on the byte raster → get a %ones readout for that region.
- "Take the guided tour" walks Act 1 on every run and Act 2 when crypto is
  present, never pointing at a missing panel.
- The import/analyse window is unchanged and still loved.
- §7 checks 1-10 pass in jsdom; no regressions.

---

## 10. Suggested order & rough budget

1. §7 harness up + baseline (boot, import, typing, pan) — 20 min, do FIRST.
2. T1 crypto cluster spawn + trigger — biggest value, ~40 min.
3. T2 weakness RAG (port) — ~20 min.
4. T5 tour rebuild + embedded sample — ~40 min (depends on T1 for Act 2).
5. T3 raster drag-select (port + adapt) — ~30 min.
6. T4 WHT panel (port) — ~30 min, can defer if time-boxed.
7. T6 wiring/discoverability + final §7 full pass — ~20 min.

If time-boxed, ship after step 4 (cluster + RAG + tour) — that alone answers the
user's request. T3/T4 are the "nice to also have back".

---

## 11. One open question to confirm with the user before or early in the build

The defaults in §3 are assumed from their "if you just say go". If they reply
with different choices (e.g. always-on crypto lab instead of drill-down, or skip
the WHT panel), honour that over §3. Everything else here still applies.
