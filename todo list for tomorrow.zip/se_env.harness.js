// shared jsdom environment for SE.html
const { JSDOM } = require("jsdom");
const fs=require("fs");
function boot(htmlPath){
  const html=fs.readFileSync(htmlPath,"utf8");
  const script=html.match(/<script>([\s\S]*)<\/script>/)[1];
  const dom=new JSDOM(html,{runScripts:"outside-only",pretendToBeVisual:true});
  const win=dom.window,doc=win.document;
  win.HTMLCanvasElement.prototype.getContext=()=>new Proxy({},{get(_,k){
    if(k==="measureText")return ()=>({width:0});
    if(k==="createImageData")return (w,h)=>({data:new Uint8ClampedArray(Math.max(4,(w|0)*(h|0)*4)),width:w,height:h});
    if(k==="getImageData")return (x,y,w,h)=>({data:new Uint8ClampedArray(Math.max(4,(w|0)*(h|0)*4))});
    if(k==="createLinearGradient"||k==="createRadialGradient")return ()=>({addColorStop(){}});
    return ()=>{};
  }});
  win.Element.prototype.setPointerCapture=function(){};win.Element.prototype.releasePointerCapture=function(){};
  win.HTMLElement.prototype.scrollIntoView=function(){};
  win.HTMLElement.prototype.getBoundingClientRect=function(){return{left:0,top:0,right:1400,bottom:900,width:1400,height:900,x:0,y:0};};
  Object.defineProperty(win.HTMLElement.prototype,"offsetWidth",{get(){return 1400;},configurable:true});
  Object.defineProperty(win.HTMLElement.prototype,"offsetHeight",{get(){return 900;},configurable:true});
  global.window=win;global.document=doc;global.navigator=win.navigator;global.location=win.location;
  global.PointerEvent=win.PointerEvent;global.MouseEvent=win.MouseEvent;global.KeyboardEvent=win.KeyboardEvent;global.Event=win.Event;global.WheelEvent=win.WheelEvent||win.MouseEvent;
  global.FileReader=win.FileReader;global.Blob=win.Blob;global.File=win.File;global.TextEncoder=global.TextEncoder||win.TextEncoder;global.TextDecoder=global.TextDecoder||win.TextDecoder;
  global.getComputedStyle=win.getComputedStyle.bind(win);global.matchMedia=()=>({matches:false,addEventListener(){},removeEventListener(){}});win.matchMedia=global.matchMedia;
  global.requestAnimationFrame=cb=>setTimeout(()=>cb(Date.now()),0);win.requestAnimationFrame=global.requestAnimationFrame;global.cancelAnimationFrame=()=>{};win.cancelAnimationFrame=()=>{};
  global.devicePixelRatio=1;win.devicePixelRatio=1;
  const stx={};global.localStorage={getItem:k=>k in stx?stx[k]:null,setItem:(k,v)=>{stx[k]=String(v);},removeItem:()=>{},clear(){}};win.localStorage=global.localStorage;
  global.atob=s=>Buffer.from(s,"base64").toString("binary");global.btoa=s=>Buffer.from(s,"binary").toString("base64");win.atob=global.atob;win.btoa=global.btoa;
  let selftest=null; const realLog=console.log;
  console.log=(...a)=>{const s=a.map(String).join(" "); if(/self-test|self test/i.test(s))selftest=s;};
  let threw=null;
  try{ (0,eval)(script+"\n;globalThis.__api={S,V,COMPUTED,getObj,loadInputBytes,byteSourceOf,RENDER,bytesToB64};"); }
  catch(e){ threw=e; }
  console.log=realLog;
  return { win, doc, get:()=>globalThis.__api, selftest:()=>selftest, threw };
}
module.exports={boot};
